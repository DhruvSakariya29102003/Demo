//
//  SideView.swift
//  Pagination
//
//  Created by Droadmin on 18/09/23.
//

import UIKit

class SideView: UIView {
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var moviNameLbl: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
